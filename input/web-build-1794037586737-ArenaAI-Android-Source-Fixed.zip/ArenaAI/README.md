# Arena AI (Android WebView wrapper)

A lightweight Android app shell that opens the official Arena website in a dedicated app window.

- App label: Arena AI
- Start URL: https://arena.ai/
- Allows Arena/Arena subdomains and legacy lmarena.ai domains inside the app; external links open in the browser.
- JavaScript, DOM storage, cookies and file upload chooser are enabled for site functionality.

## Build APK

1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will create the debug APK under `app/build/outputs/apk/debug/`.

This is an independent third-party wrapper, not an official Arena app. Website behavior, login persistence and media/upload features depend on Arena's compatibility with Android WebView and its own policies. The source has not been compiled or device-tested in this environment.
